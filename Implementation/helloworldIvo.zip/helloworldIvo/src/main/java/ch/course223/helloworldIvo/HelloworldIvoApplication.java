package ch.course223.helloworldIvo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloworldIvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloworldIvoApplication.class, args);
	}

}
