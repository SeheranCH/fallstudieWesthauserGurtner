package ch.course223.helloworldIvo.domainModells.authority.dto;

public class AuthorityDTO {

    private String id;

    private String name;

    public AuthorityDTO() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
