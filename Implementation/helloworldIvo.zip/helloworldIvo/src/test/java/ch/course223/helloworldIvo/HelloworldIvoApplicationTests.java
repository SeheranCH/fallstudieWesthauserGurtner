package ch.course223.helloworldIvo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldIvoApplicationTests {

	@Test
	void contextLoads() {
	}

}
